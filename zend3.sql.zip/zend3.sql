-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Czas generowania: 21 Maj 2019, 20:35
-- Wersja serwera: 5.6.21
-- Wersja PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `zend3`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `comics`
--

CREATE TABLE IF NOT EXISTS `comics` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `thumb` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `comics`
--

INSERT INTO `comics` (`id`, `title`, `thumb`) VALUES
(1, 'batman', 'bat.png'),
(2, 'spiderman', 'spider.jpg'),
(3, 'updated thor', 'bolt.jpg'),
(4, 'updated hulk3', 'zielony2.png'),
(5, 'kapitan ameryka', 'kapitan.jpg');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `comics2`
--

CREATE TABLE IF NOT EXISTS `comics2` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `thumb` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `required` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `pages`
--

INSERT INTO `pages` (`id`, `name`, `url`, `parent_id`, `required`) VALUES
(1, 'Stopka', 'stopka', 0, 1),
(2, 'Nagłówek artykułu', 'test_article', 0, 0),
(3, 'Footer', 'footer', 0, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_contents`
--

CREATE TABLE IF NOT EXISTS `page_contents` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `page_contents`
--

INSERT INTO `page_contents` (`id`, `name`) VALUES
(5, 'Footer'),
(4, 'Stopka'),
(2, 'Zawartość 1');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_lang_contents`
--

CREATE TABLE IF NOT EXISTS `page_lang_contents` (
`id` int(10) unsigned NOT NULL,
  `lang` varchar(2) CHARACTER SET utf32 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `page_content_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `page_lang_contents`
--

INSERT INTO `page_lang_contents` (`id`, `lang`, `content`, `page_content_id`) VALUES
(1, 'pl', '<h1>Nagł&oacute;wek Artykułu</h1>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce tempus molestie metus non fringilla</strong>. Phasellus orci velit, dictum sit amet vulputate ullamcorper, semper lacinia nunc. Curabitur tempus est non dolor rhoncus, eu maximus nisi rutrum. Pellentesque non neque enim. Pellentesque venenatis consequat ipsum, lobortis sodales dolor. In nec metus at lorem semper placerat. Nam maximus iaculis sapien, in efficitur orci luctus id. Donec ipsum odio, laoreet at mauris vitae, condimentum interdum tortor. Ut convallis consectetur ligula, nec ullamcorper velit. <strong><span style="color:#8e44ad">Cras sed augue risus</span></strong>. Nam tempus, mi vel porta mollis, lectus velit placerat justo, vel mollis dui lacus sit amet magna. Ut sed rutrum dui. Sed congue mollis orci, et efficitur est venenatis a. <u>Fusce scelerisque urna id ante blandit consequat</u>.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Nam maximus iaculis sapien, in efficitur orci luctus id. Donec ipsum odio, laoreet at mauris vitae, condimentum interdum tortor. Ut convallis consectetur ligula, nec ullamcorper velit. <s><em><span style="color:#8e44ad">Cras sed augue risus</span></em></s>. Nam tempus, mi vel porta mollis, lectus velit placerat justo, vel mollis dui lacus sit amet magna. Ut sed rutrum dui. Sed congue mollis orci, et efficitur est venenatis a. <sup><u>Fusce scelerisque urna id ante blandit consequat</u>.</sup></p>\r\n', 2),
(6, 'en', '<p>bbb 3</p>\r\n', 2),
(7, 'pl', '<hr />\r\n<p>2017 Zend Framework 3 - Podręcznik Programisty.</p>\r\n', 4),
(8, 'pl', '<hr />\r\n<p>2017 Zend Framework 3 - Developer''s Guide. Adam Omelak.</p>\r\n', 5);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_metadata`
--

CREATE TABLE IF NOT EXISTS `page_metadata` (
`id` int(10) unsigned NOT NULL,
  `lang` varchar(3) CHARACTER SET latin1 NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `page_metadata`
--

INSERT INTO `page_metadata` (`id`, `lang`, `title`, `description`, `keywords`, `page_id`) VALUES
(1, 'pl', 'Jaki? tytu?', 'Opiisss', 'klucze', 0),
(2, 'pl', 'aa', 'bb2', 'cc', 1),
(3, 'pl', 'Strona Artykułu', 'Opis Artykułu', 'Słowa kluczowe artykułu', 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_to_contents`
--

CREATE TABLE IF NOT EXISTS `page_to_contents` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `page_to_contents`
--

INSERT INTO `page_to_contents` (`id`, `page_id`, `content_id`) VALUES
(1, 1, 4),
(5, 2, 2),
(6, 3, 5);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` char(128) DEFAULT NULL,
  `password_salt` varchar(8) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'user',
  `gender` varchar(10) DEFAULT NULL,
  `education` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `password_salt`, `name`, `email`, `role`, `gender`, `education`) VALUES
(1, 'divix', 'password', '', 'adam', '', 'User', '0', ''),
(2, 'abc3', '', '', '', '', 'User', '0', ''),
(3, 'abcqq', '', '', '', 'aa@wp.pl', 'User', 'female', 'graduate'),
(4, 'test_auth', '43df3b5273841d8440228822bd809033f249893e3247da4c71982f1ce3428420202e8e316af10665b88b4139ff00ed57b326ce69f53e1e56beff377095e4da8f', 't9ixF7gj', 'Użytkownik', 'przyklad@gmail.com', 'user', 'male', 'graduate'),
(20, '456aaw ', '8fdd78653926d2705feef02bb70d1c406386c215a95233ba6827a856be34db1a50ec0cfab33ea87f92d863afc4330d28625194777963a8db70f0a09830cfea72', '1EYGBaXf', '', 'aa2@wp.pl', 'user', NULL, NULL),
(21, 'Admin', '8fdd78653926d2705feef02bb70d1c406386c215a95233ba6827a856be34db1a50ec0cfab33ea87f92d863afc4330d28625194777963a8db70f0a09830cfea72', '1EYGBaXf', '', 'admin@funkcje.net', 'admin', NULL, NULL),
(22, 'ww ', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, '123', NULL, NULL, NULL, NULL, 'user', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `user_hobbies`
--

CREATE TABLE IF NOT EXISTS `user_hobbies` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `hobby` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `user_hobbies`
--

INSERT INTO `user_hobbies` (`id`, `user_id`, `hobby`) VALUES
(18, 3, 'sport'),
(19, 3, 'movies'),
(20, 23, 'sport');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indexes for table `comics`
--
ALTER TABLE `comics`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comics2`
--
ALTER TABLE `comics2`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`name`);

--
-- Indexes for table `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
 ADD PRIMARY KEY (`id`), ADD KEY `lang` (`lang`);

--
-- Indexes for table `page_metadata`
--
ALTER TABLE `page_metadata`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_to_contents`
--
ALTER TABLE `page_to_contents`
 ADD PRIMARY KEY (`id`), ADD KEY `page_id` (`page_id`,`content_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_hobbies`
--
ALTER TABLE `user_hobbies`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `comics`
--
ALTER TABLE `comics`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT dla tabeli `comics2`
--
ALTER TABLE `comics2`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT dla tabeli `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT dla tabeli `page_contents`
--
ALTER TABLE `page_contents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT dla tabeli `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT dla tabeli `page_metadata`
--
ALTER TABLE `page_metadata`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT dla tabeli `page_to_contents`
--
ALTER TABLE `page_to_contents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT dla tabeli `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT dla tabeli `user_hobbies`
--
ALTER TABLE `user_hobbies`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
