<?php
return array(
    'db' => array(
        'username' => 'root',
        'password' => '',
    ),
    'zf-mvc-auth' => array(
        'authentication' => array(
            'adapters' => array(
                'comics' => array(
                    'adapter' => 'ZF\\MvcAuth\\Authentication\\HttpAdapter',
                    'options' => array(
                        'accept_schemes' => array(
                            0 => 'basic',
                        ),
                        'realm' => 'comicsApi',
                        'htpasswd' => 'data/comics.htpasswd',
                    ),
                ),
            ),
        ),
    ),
);
