<?php

return [
    'abc' => 'translator działa',
    'abc_param' => 'translator %s działa',
    'abc_params' => 'translator działa %2$s %1$s'
];