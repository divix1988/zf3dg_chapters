<?php

return [
    'abc' => 'translator works',
    'abc_param' => 'translator %s works',
    'abc_params' => 'translator works %2$s %1$s'
];