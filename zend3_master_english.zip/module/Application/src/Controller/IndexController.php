<?php

namespace Application\Controller;

use Zend\View\Model\ViewModel;
use Application\Model\UsersTable;
use Main_View_Smarty;

class IndexController extends AbstractController
{
    private $usersTable = null;
    
    public function __construct(UsersTable $usersTable)
    {
         $this->usersTable = $usersTable;
    }

    public function indexAction()
    {
        $view = new ViewModel();
        $model = $this->usersTable;
        $row = $model->getById(1);

        $view->setVariable('id', $row->getId());
        $view->setVariable('username', $row->getUsername());
        $view->setVariable('password', $row->getPassword());
        
        \DivixUtils\Logs\Debug::dump('short message');
        \DivixUtils\Logs\Debug::dump('medium message', ['desc' => 'medium', 'log' => true]);
        \DivixUtils\Logs\Debug::dump('wiadomość long', ['desc' => 'long']);
        //metoda();
        //
        //$this->getResponse()->setStatusCode(404);
        //throw new \Exception('Our custom exception');

        return $view;
    }
}
