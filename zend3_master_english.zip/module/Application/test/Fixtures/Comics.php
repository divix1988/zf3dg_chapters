<?php

return [
    [
        'id' => 1,
        'title' => 'Przykładowy komiks',
        'thumb' => 'public/images/comics/test.jpg'
    ],
    [
        'id' => 2,
        'title' => 'Spiderman',
        'thumb' => 'public/images/comics/spiderman.jpg'
    ],
    [
        'id' => 3,
        'title' => 'Batman',
        'thumb' => 'public/images/comics/batman.jpg'
    ]
];