<?php

namespace Admin\Controller;

class AdminController extends AbstractController
{
    public function indexAction()
    {
        return [];
    }
}
