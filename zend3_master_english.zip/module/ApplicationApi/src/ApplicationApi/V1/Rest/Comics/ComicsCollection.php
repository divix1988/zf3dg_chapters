<?php
namespace ApplicationApi\V1\Rest\Comics;

use Zend\Paginator\Paginator;

class ComicsCollection extends Paginator
{
}
